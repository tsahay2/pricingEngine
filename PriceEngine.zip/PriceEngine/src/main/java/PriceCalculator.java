import Domain.Competetor;
import Domain.Product;

import java.util.*;

/**
 * Created by TUSHAR on 29-11-2016.
 */
public class PriceCalculator {

    private static int minPrice;


    static void calculatePrice(Product product)
    {
      // product.setPrice(findMinimum(product.getCompetetors())) ;
        int average=findAverage(product.getCompetetors()) ;
        int promotionPrice= (int) (average*0.5);
        int errorPrice =(int)(average*1.5) ;
        System.out.println("promotion "+promotionPrice+"  error "+errorPrice);


      product.setPrice(findPriceFromMostFrequent(calculateValidItemsFrequency(product.getCompetetors(),promotionPrice,errorPrice))) ;


    }



    static int findMinimum(List<Competetor> competetors)
    {
        int minimum=competetors.get(0).getPrice() ;
        for(Competetor competetor:competetors)
        {

            if(competetor.getPrice()<minimum)
            {
                minimum=competetor.getPrice() ;
            }
        }
        return minimum ;
    }

    static   Map<Integer,Integer> calculateValidItemsFrequency(List<Competetor> competetors, int promotionPrice, int errorPrice){

        Map<Integer,Integer> freqeuncyMapper= new TreeMap<Integer, Integer>();
        int average=findAverage(competetors) ;

            for(Competetor competetor:competetors)
            {
                if (!(competetor.getPrice() > (errorPrice) || competetor.getPrice() < (promotionPrice)))
                {

                    if (freqeuncyMapper.get(competetor.getPrice()) == null)
                    {

                        freqeuncyMapper.put(competetor.getPrice(), 1);

                    }
                    else
                    {
                        freqeuncyMapper.put(competetor.getPrice(), freqeuncyMapper.get(competetor.getPrice()) + 1);
                    }
                }
            }
            return freqeuncyMapper ;
    }

    static int findPriceFromMostFrequent(Map<Integer,Integer> freqeuncyMapper){
        for (int i:freqeuncyMapper.keySet())
        {
            if(freqeuncyMapper.get(i)==Collections.max(freqeuncyMapper.values()))
            {
                System.out.println("Price is"+i);
                minPrice = i;
                break;
            }

        }

        return minPrice ;
    }


    static int findAverage(List<Competetor> competetors){
        int average=0 ;
        int sum=0 ;

        for(Competetor competetor:competetors) {
                sum+=competetor.getPrice() ;
        }
        return sum/competetors.size() ;

    }


    }

