/**
 * Created by TUSHAR on 30-11-2016.
 */
public class InputInvalidException extends Exception {

    public InputInvalidException(String message)
    {
        super(message);
    }
}
