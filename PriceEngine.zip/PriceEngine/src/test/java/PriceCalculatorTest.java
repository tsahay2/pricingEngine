import Domain.Product;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by TUSHAR on 29-11-2016.
 */
public class PriceCalculatorTest {

    @Test
    public void shoulsGiveMinimum() throws Exception {
        List<Product> products=InputReader.read();
        PriceCalculator.calculatePrice(products.get(0));
        assertEquals(12,products.get(0).getPrice());

    }

    @Test
    public void shoulsGiveMaxFrequency() throws Exception {
        List<Product> products=InputReader.read();
        PriceCalculator.calculatePrice(products.get(0));
        System.out.println(products.get(0).getPrice());
        assertEquals(10,products.get(0).getPrice());

    }

    @Test
    public void shouldTestAverage() throws Exception {

        List<Product> products=InputReader.read();
        PriceCalculator.calculatePrice(products.get(0));
        System.out.println(products.get(0).getPrice());
        assertEquals(10,products.get(0).getPrice());

    }



    @Test
    public void shouldDiscardInvalidPrices() throws Exception{

        List<Product> products=InputReader.read();
        PriceCalculator.calculatePrice(products.get(0));
        System.out.println(products.get(0).getPrice());
        assertEquals(2,products.get(0).getPrice());


    }

}